# Aprendiendo a Aprender 	&#128161;
## Desarrollador web

*Este proyecto es para aprender y fortalecer los conocimientos adquiridos en el programa de Practicum by Yandex en el desarrollo de paginas web. Este programa ofrecido por Practicum se divide en sprints, en el que al final de cada sprint se realiza un proyecto con los conocimientos previamente adquiridos en el programa, este proyecto va creciendo y combinando varias tecnicas utilizadas en el desarrollo web.*

*Esta fase del programa se encuentra en HTML y CSS II visualizando la prueba final del proyecto 2 en el cual se pone en practica:*


* Creacion de bloques 
* Organizacion de archivos segun BEM
* animaciones 
* insercion de videos
* Insercion de links 
* Creacion de listas y mas
* Creacion de archivo readme.md

    <img src="../web_project_1_es-main/images/GIF/dog.gif" width="150" height="190">
    